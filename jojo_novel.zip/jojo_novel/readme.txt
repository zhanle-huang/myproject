npm i express --save
npm i body-parse --save
npm i mysql --save