(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/sideCategoryList/index-anchor"],{"021e":function(t,e,n){"use strict";var u;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return u}));var r=function(){var t=this,e=t.$createElement,n=(t._self._c,t.__get_style([t.wrapperStyle])),u=t.__get_style([t.customAnchorStyle]);t.$mp.data=Object.assign({},{$root:{s0:n,s1:u}})},a=[]},1941:function(t,e,n){"use strict";n.r(e);var u=n("021e"),r=n("5f00");for(var a in r)"default"!==a&&function(t){n.d(e,t,(function(){return r[t]}))}(a);n("7ddb");var c,o=n("f0c5"),i=Object(o["a"])(r["default"],u["b"],u["c"],!1,null,"9eb7b986",null,!1,u["a"],c);e["default"]=i.exports},"5f00":function(t,e,n){"use strict";n.r(e);var u=n("8d3f"),r=n.n(u);for(var a in u)"default"!==a&&function(t){n.d(e,t,(function(){return u[t]}))}(a);e["default"]=r.a},"7ddb":function(t,e,n){"use strict";var u=n("d22a"),r=n.n(u);r.a},"8d3f":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={name:"u-index-anchor",props:{useSlot:{type:Boolean,default:!1},index:{type:String,default:""},customStyle:{type:Object,default:function(){return{}}}},data:function(){return{active:!1,wrapperStyle:{},anchorStyle:{}}},inject:["UIndexList"],mounted:function(){this.UIndexList.children.push(this),this.UIndexList.updateData()},computed:{customAnchorStyle:function(){return Object.assign(this.anchorStyle,this.customStyle)}}};e.default=u},d22a:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/sideCategoryList/index-anchor-create-component',
    {
        'components/sideCategoryList/index-anchor-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("1941"))
        })
    },
    [['components/sideCategoryList/index-anchor-create-component']]
]);
