(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/book-list/book-list"],{6374:function(t,n,e){"use strict";var a;e.d(n,"b",(function(){return r})),e.d(n,"c",(function(){return u})),e.d(n,"a",(function(){return a}));var r=function(){var t=this,n=t.$createElement,e=(t._self._c,t.__map(t.bookListData,(function(n,e){var a=t.__get_orig(n),r=t.statusToText(n.status),u=t._f("formatNumber")(n.total/1e4);return{$orig:a,m0:r,f0:u}})));t.$mp.data=Object.assign({},{$root:{l0:e}})},u=[]},"63e2":function(t,n,e){},8036:function(t,n,e){"use strict";e.r(n);var a=e("6374"),r=e("a13e");for(var u in r)"default"!==u&&function(t){e.d(n,t,(function(){return r[t]}))}(u);e("c076");var o,c=e("f0c5"),i=Object(c["a"])(r["default"],a["b"],a["c"],!1,null,"b5ea2990",null,!1,a["a"],o);n["default"]=i.exports},a13e:function(t,n,e){"use strict";e.r(n);var a=e("d0a9"),r=e.n(a);for(var u in a)"default"!==u&&function(t){e.d(n,t,(function(){return a[t]}))}(u);n["default"]=r.a},c076:function(t,n,e){"use strict";var a=e("63e2"),r=e.n(a);r.a},d0a9:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"bookList",props:{bookListData:{type:Array,default:function(){return[]}}},data:function(){return{}},methods:{statusToText:function(t){switch(t){case 0:return"完结";case 1:return"连载中";case 2:return"停更"}}}};n.default=a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/book-list/book-list-create-component',
    {
        'components/book-list/book-list-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("8036"))
        })
    },
    [['components/book-list/book-list-create-component']]
]);
