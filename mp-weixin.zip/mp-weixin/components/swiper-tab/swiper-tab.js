(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/swiper-tab/swiper-tab"],{3136:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={props:{currentTab:{type:Number,default:0},tabs:{type:Array,default:function(){return[]}}},data:function(){return{}},methods:{}};n.default=r},"6dd9":function(t,n,e){"use strict";e.r(n);var r=e("c70b"),u=e("a2da");for(var a in u)"default"!==a&&function(t){e.d(n,t,(function(){return u[t]}))}(a);var c,f=e("f0c5"),o=Object(f["a"])(u["default"],r["b"],r["c"],!1,null,"6d765d4e",null,!1,r["a"],c);n["default"]=o.exports},a2da:function(t,n,e){"use strict";e.r(n);var r=e("3136"),u=e.n(r);for(var a in r)"default"!==a&&function(t){e.d(n,t,(function(){return r[t]}))}(a);n["default"]=u.a},c70b:function(t,n,e){"use strict";var r;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){return r}));var u=function(){var t=this,n=t.$createElement;t._self._c},a=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/swiper-tab/swiper-tab-create-component',
    {
        'components/swiper-tab/swiper-tab-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("6dd9"))
        })
    },
    [['components/swiper-tab/swiper-tab-create-component']]
]);
