(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/category-card/category-card"],{"0604":function(t,n,e){"use strict";e.r(n);var r=e("8c56"),u=e.n(r);for(var a in r)"default"!==a&&function(t){e.d(n,t,(function(){return r[t]}))}(a);n["default"]=u.a},"336d":function(t,n,e){"use strict";var r;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){return r}));var u=function(){var t=this,n=t.$createElement;t._self._c},a=[]},"8c56":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={props:{categoryTop:{type:Array,default:function(){return[]}},categoryBottom:{type:Array,default:function(){return[]}},tip1:{type:String,default:""},tip2:{type:String,default:""}},data:function(){return{categoryData:{categoryTop:[],categoryBottom:[]}}},methods:{},mounted:function(){}};n.default=r},cb8b:function(t,n,e){"use strict";var r=e("f797"),u=e.n(r);u.a},e841:function(t,n,e){"use strict";e.r(n);var r=e("336d"),u=e("0604");for(var a in u)"default"!==a&&function(t){e.d(n,t,(function(){return u[t]}))}(a);e("cb8b");var c,o=e("f0c5"),f=Object(o["a"])(u["default"],r["b"],r["c"],!1,null,"4330b732",null,!1,r["a"],c);n["default"]=f.exports},f797:function(t,n,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/category-card/category-card-create-component',
    {
        'components/category-card/category-card-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("e841"))
        })
    },
    [['components/category-card/category-card-create-component']]
]);
